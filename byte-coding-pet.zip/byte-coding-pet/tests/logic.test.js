const test = require("node:test");
const assert = require("node:assert");
const { calc, stageOf, tier, key, dayDiff } = require("../js/logic.js");

const daysAgo = (n) => {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return key(d);
};
const entry = (o = {}) => Object.assign({ f: 0, t: 0, s: 0, y: 0, l: 0, r: 0 }, o);

test("an empty history has no XP, streak or coins", () => {
  const c = calc({});
  assert.strictEqual(c.xp, 0);
  assert.strictEqual(c.streak, 0);
  assert.strictEqual(c.earn, 0);
});

test("a plain check-in is worth 10 XP and 5 coins", () => {
  const c = calc({ [daysAgo(0)]: entry() });
  assert.strictEqual(c.xp, 10);
  assert.strictEqual(c.earn, 5);
});

test("a rest day gives 6 XP", () => {
  assert.strictEqual(calc({ [daysAgo(0)]: entry({ r: 1 }) }).xp, 6);
});

test("focus, craft and curiosity add the documented XP", () => {
  const c = calc({ [daysAgo(0)]: entry({ f: 90, t: 1, s: 1, y: 1, l: 1 }) });
  // 10 + 20 + (8+8+6) + 12
  assert.strictEqual(c.xp, 64);
  assert.strictEqual(c.P.fo, 20);
  assert.strictEqual(c.P.cr, 22);
  assert.strictEqual(c.P.cu, 12);
});

test("streak bonus grows by 1 per consecutive day, capped at +7", () => {
  const days = {};
  for (let i = 0; i < 10; i++) days[daysAgo(i)] = entry();
  const c = calc(days);
  assert.strictEqual(c.streak, 10);
  // day 1..10 -> 10 + min(run-1,7)
  const expected = [0, 1, 2, 3, 4, 5, 6, 7, 7, 7].reduce((a, b) => a + 10 + b, 0);
  assert.strictEqual(c.xp, expected);
});

test("a gap of more than one day resets the streak", () => {
  const c = calc({ [daysAgo(5)]: entry(), [daysAgo(4)]: entry() });
  assert.strictEqual(c.streak, 0);
  assert.strictEqual(c.best, 2);
});

test("every 7th streak day awards 15 bonus coins", () => {
  const days = {};
  for (let i = 6; i >= 0; i--) days[daysAgo(i)] = entry();
  const c = calc(days);
  const base = Object.values(c.xpd).reduce((a, x) => a + Math.floor(x / 2), 0);
  assert.strictEqual(c.earn, base + 15);
});

test("stage thresholds", () => {
  assert.strictEqual(stageOf(0), 0);
  assert.strictEqual(stageOf(25), 1);
  assert.strictEqual(stageOf(100), 2);
  assert.strictEqual(stageOf(250), 3);
  assert.strictEqual(stageOf(500), 4);
});

test("habit tiers level at 20, 60 and 120 points", () => {
  assert.strictEqual(tier(19), 0);
  assert.strictEqual(tier(20), 1);
  assert.strictEqual(tier(60), 2);
  assert.strictEqual(tier(120), 3);
});

test("dayDiff counts whole days", () => {
  assert.strictEqual(dayDiff("2026-01-01", "2026-01-03"), 2);
});
