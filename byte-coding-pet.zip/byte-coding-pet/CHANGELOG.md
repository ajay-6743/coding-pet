# Changelog

All notable changes to this project are documented here.

## [1.0.0] - 2026-10-27

### Added
- Daily check-in with focus blocks and habit chips.
- Four habits (Spark, Focus, Craft, Curiosity) with three levels each.
- Five life stages from Egg to Legend.
- Streaks with rest days.
- Coins and seven cosmetic skins.
- Import from `git log`.
- 14-day history and light/dark themes.
- Unit tests for the XP, streak and coin logic.
