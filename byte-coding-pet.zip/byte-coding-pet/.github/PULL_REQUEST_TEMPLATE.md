## What does this change?

## Checklist
- [ ] `npm test` passes
- [ ] Works in light and dark mode
- [ ] No new dependencies
- [ ] Docs / README updated if behavior changed
