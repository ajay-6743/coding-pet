---
name: Feature request
about: Suggest a new idea, skin or habit
labels: enhancement
---

**What would you like to see?**

**Why would it be useful?**

**Anything else?**
