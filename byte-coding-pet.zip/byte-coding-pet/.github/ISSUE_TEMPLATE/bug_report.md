---
name: Bug report
about: Something isn't working as expected
labels: bug
---

**What happened?**

**What did you expect?**

**Steps to reproduce**
1.
2.

**Browser and device**

**Screenshot (optional)**
