# 🐣 Byte, your coding pet

A tiny virtual pet that grows with your coding habits. Check in each day, feed Byte, and watch it hatch, evolve and pick up accessories as your habits level up.

No accounts, no build step, no dependencies. Just open `index.html`.

## Features

- **Daily check-in**: log a deep focus block and what you did (tests, small commits, tidying up, learning).
- **Four habits**: Spark 🔥, Focus 🎯, Craft 🛠️ and Curiosity 📚. Each levels up and visibly changes how Byte looks.
- **Five life stages**: Egg → Hatchling → Critter → Coder → Legend.
- **Streaks with rest days**: a rest day keeps your streak alive. Missed days only make Byte sleepy, XP never goes down.
- **Coins and skins**: earn coins, then spend them on seven skins (Classic, Sunset, Ocean, Moss, Terminal, Cosmic, Golden).
- **Import from git**: paste your `git log` output and Byte learns from your real commit history. Only dates and flags are saved.
- **14-day history** heatmap and streak counter.
- **Light and dark mode**, keyboard accessible, respects `prefers-reduced-motion`.
- **Local first**: data lives in your browser's `localStorage`.

## Quick start

```bash
git clone https://github.com/<your-username>/byte-coding-pet.git
cd byte-coding-pet
```

Then either double-click `index.html`, or serve it locally:

```bash
npm start        # runs a static server via npx serve
```

## How Byte grows

| Source | XP |
| --- | --- |
| Check-in | 10, plus up to 7 bonus XP as your streak grows |
| Rest day | 6 (streak is kept) |
| Focus block | 25 min = 6, 50 min = 12, 90+ min = 20 |
| Wrote or ran tests | 8 |
| Kept commits small | 8 |
| Tidied up code | 6 |
| Learned something new | 12 |

**Stages:** Hatchling at 25 XP, Critter at 100, Coder at 250, Legend at 500.

**Habit levels:** each habit levels up at 20, 60 and 120 points.

**Coins:** 1 coin per 2 XP earned, plus 15 bonus coins every time your streak reaches a multiple of 7 days. Skins are cosmetic only.

More detail in [docs/how-it-grows.md](docs/how-it-grows.md).

## Import from git

Run this inside a repository:

```bash
git log --since="90 days ago" --author="$(git config user.email)" --pretty=format:"%ad|%s" --date=short
```

Paste the output into the **Import from git** panel. Or use the helper script, which does the same thing across the current repo:

```bash
./scripts/export-git-log.sh | pbcopy   # macOS; use xclip/wl-copy on Linux
```

See [docs/import-from-git.md](docs/import-from-git.md) for how commit messages are interpreted.

## Project structure

```
.
├── index.html                  # Page markup
├── css/styles.css              # Styles (light/dark themes via CSS variables)
├── js/
│   ├── logic.js                # Pure XP / streak / coin logic (unit-tested)
│   ├── pet.js                  # SVG rendering of Byte and skin previews
│   └── app.js                  # State, UI, persistence, event handlers
├── tests/logic.test.js         # Node built-in test runner
├── docs/                       # Extra documentation
├── scripts/export-git-log.sh   # Helper for the git import
└── .github/                    # CI/deploy workflow, issue + PR templates
```

The scripts are plain (non-module) `<script>` tags loaded in order, so the app works straight from `file://` with no bundler.

## Tests

Requires Node 18+.

```bash
npm test
```

## Deploying to GitHub Pages

A workflow in `.github/workflows/pages.yml` publishes the site on every push to `main`. In your repository go to **Settings → Pages → Build and deployment** and set **Source** to **GitHub Actions**.

## Contributing

Ideas, skins and bug fixes are welcome. See [CONTRIBUTING.md](CONTRIBUTING.md).

## License

[MIT](LICENSE)
