# How Byte grows

## XP per check-in

| Source | XP |
| --- | --- |
| Check-in | 10 + streak bonus (`min(streak - 1, 7)`) |
| Rest day | 6 + streak bonus, streak is kept |
| Focus 25 / 50 / 90+ min | 6 / 12 / 20 |
| Tests | 8 |
| Small commits | 8 |
| Tidy-ups | 6 |
| Learning | 12 |

## Habits

Each habit collects points from specific actions:

| Habit | Points from |
| --- | --- |
| 🔥 Spark | Check-ins and streak bonus |
| 🎯 Focus | Focus blocks |
| 🛠️ Craft | Tests, small commits, tidy-ups |
| 📚 Curiosity | Learning something new |

Each habit levels up at **20, 60 and 120** points and changes Byte's look:

- Spark: flames
- Focus: glasses, then a halo
- Craft: belly patch, side plates, then a badge
- Curiosity: antennae, then orbiting dots

With the Classic skin, Byte's color follows your strongest habit.

## Stages

| Stage | XP needed |
| --- | --- |
| Egg | 0 |
| Hatchling | 25 |
| Critter | 100 |
| Coder | 250 |
| Legend | 500 |

XP never decreases. If you miss days, Byte just gets sleepy.

## Coins

- 1 coin for every 2 XP earned on a day.
- +15 coins each time your streak reaches a multiple of 7.
- Skins cost 30 to 120 coins and are purely cosmetic.

The implementation lives in `calc()` in [`js/logic.js`](../js/logic.js).
