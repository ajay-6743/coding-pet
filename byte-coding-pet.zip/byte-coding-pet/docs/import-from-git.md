# Import from git

The importer reads lines in the format `YYYY-MM-DD|commit message`.

```bash
git log --since="90 days ago" --author="$(git config user.email)" --pretty=format:"%ad|%s" --date=short
```

## What it detects

For each day it finds commits on:

| Flag | Rule |
| --- | --- |
| Tests | a message mentions `test` or `spec` |
| Small commits | 3 or more commits that day |
| Tidy-up | a message mentions `refactor`, `clean`, `tidy` or `rename` |
| Learning | a message mentions `learn`, `try`, `trying`, `experiment`, `spike`, `prototype` or `explor…` |

Existing check-ins are kept: a flag already set on a day is never cleared.

## Privacy

Only the **date** and the **flags** are stored, in your browser's `localStorage`. Commit messages are not saved and nothing is sent anywhere.

## Tips

- Run it in several repositories and paste each output one after another.
- Lines that don't start with a valid date are ignored.
