#!/usr/bin/env bash
# Print your recent commits in the "date|message" format Byte can import.
# Usage: ./scripts/export-git-log.sh [days]   (default: 90)
set -euo pipefail

days="${1:-90}"

if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "Run this inside a git repository." >&2
  exit 1
fi

git log \
  --since="${days} days ago" \
  --author="$(git config user.email)" \
  --pretty=format:"%ad|%s" \
  --date=short
echo
