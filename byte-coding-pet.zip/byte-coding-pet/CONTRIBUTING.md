# Contributing

Thanks for helping Byte grow! 🐣

## Setup

No build step. Clone the repo and open `index.html`, or run `npm start`.

```bash
npm test     # Node 18+
```

## Guidelines

- Keep it dependency-free: plain HTML, CSS and JavaScript.
- Put pure logic (XP, streaks, coins) in `js/logic.js` and add a test in `tests/`.
- Keep DOM code in `js/app.js` and SVG drawing in `js/pet.js`.
- Colors come from the CSS variables in `css/styles.css` so light and dark mode both work.
- Keep it accessible: real `<button>`s, visible focus, `aria-live` for messages, and respect `prefers-reduced-motion`.
- Byte is gentle by design: XP never goes down and missed days never punish.

## Adding a skin

1. Add an entry to `SKINS` in `js/logic.js` (`id`, `n`, `price`, optional `c` body color, `l` outline, `i` face color, `p` pattern).
2. If it uses a new pattern, add it to `patt()` in `js/pet.js`.
3. Check the preview card and the full pet in both light and dark mode.

## Pull requests

Branch from `main`, keep changes focused, run `npm test`, and fill in the PR template.
