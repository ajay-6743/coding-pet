// Rendering of Byte (and the skin previews) as inline SVG.
function pet(st,T,col,mood,prog,sk){
  if(st===0){
    const crack=prog>.5?'<path d="M82 92l10 12-8 8 12 10" fill="none" stroke="#6B5F8F" stroke-width="3" stroke-linecap="round"/>':"";
    return `<svg viewBox="0 0 200 200" role="img" aria-label="An egg"><ellipse cx="100" cy="170" rx="46" ry="6" fill="#000" opacity=".12"/><path d="M100 36C140 36 156 96 156 124c0 28-24 44-56 44s-56-16-56-44C44 96 60 36 100 36Z" fill="#F1EDFF" stroke="#6B5F8F" stroke-width="3"/><g fill="${col}" opacity=".55"><circle cx="78" cy="120" r="7"/><circle cx="118" cy="98" r="6"/><circle cx="122" cy="138" r="8"/><circle cx="92" cy="146" r="5"/></g>${crack}</svg>`;
  }
  const s=[0,.6,.8,.95,1.08][st],K="#1B1B2F",L=sk.l||K,I=sk.i||K,B=sk.c||col,closed=mood==="nap"||mood==="sleepy";
  const eye=x=>closed?`<path d="M${x-7} 113q7 7 14 0" fill="none" stroke="${I}" stroke-width="3" stroke-linecap="round"/>`:`<circle cx="${x}" cy="112" r="8" fill="#fff"/><circle cx="${x+1}" cy="113" r="4.2" fill="${K}"/>${T.fo>0?`<circle cx="${x+3}" cy="110.5" r="1.6" fill="#fff"/>`:""}`;
  const mouth={happy:"M90 129q10 11 20 0",nap:"M94 132h12",sleepy:"M94 132h12",ready:"M92 130q8 6 16 0",miss:"M91 136q9-8 18 0"}[mood];
  const fl=(x,y,k)=>`<path d="M0 0C-9-10-5-19 0-28 5-19 9-10 0 0Z" transform="translate(${x} ${y}) scale(${k})" fill="#FF8A3D" stroke="#FFC83D" stroke-width="2"/>`;
  const flames=T.sp>=3?fl(84,84,1)+fl(116,84,1)+fl(100,80,1.3):T.sp===2?fl(88,84,.9)+fl(112,84,.9)+fl(100,81,1.1):T.sp===1?fl(100,81,.9):"";
  const an=(x1,x2)=>`<path d="M${x1} 84Q${(x1+x2)/2} 66 ${x2} 58" fill="none" stroke="${K}" stroke-width="3" stroke-linecap="round"/><circle cx="${x2}" cy="58" r="6" fill="#A56BFF" stroke="${K}" stroke-width="2.5"/>`;
  const ants=T.cu>=2?an(80,66)+an(120,134):T.cu===1?an(120,134):"";
  const orbit=T.cu>=3?'<g fill="#A56BFF"><circle cx="34" cy="96" r="4"/><circle cx="168" cy="70" r="3.5"/><circle cx="162" cy="146" r="4.5"/></g>':"";
  const glow=T.sp>=3?'<circle cx="100" cy="120" r="72" fill="#FFC83D" opacity=".2"/>':"";
  const halo=T.fo>=3?'<ellipse cx="100" cy="30" rx="26" ry="7" fill="none" stroke="#FFC83D" stroke-width="4"/>':"";
  const specs=T.fo>=2?`<g fill="none" stroke="${I}" stroke-width="2.5"><circle cx="84" cy="112" r="12"/><circle cx="116" cy="112" r="12"/><path d="M96 112h8"/></g>`:"";
  const belly=T.cr>=1?'<ellipse cx="100" cy="136" rx="28" ry="21" fill="#fff" opacity=".35"/>':"";
  const plates=T.cr>=2?`<g fill="#fff" opacity=".55" stroke="${K}" stroke-width="2"><rect x="44" y="112" width="15" height="28" rx="7"/><rect x="141" y="112" width="15" height="28" rx="7"/></g>`:"";
  const badge=T.cr>=3?`<path transform="translate(100 148) scale(.7)" d="M0-10l3.5 7 7.7 1.1-5.6 5.4 1.3 7.6L0 7.5l-6.9 3.6 1.3-7.6-5.6-5.4 7.7-1.1z" fill="#FFC83D" stroke="${K}" stroke-width="1.5"/>`:"";
  const zz=closed?'<text x="142" y="86" font-size="20" font-weight="800" style="fill:var(--mut)">z</text><text x="154" y="68" font-size="15" font-weight="800" style="fill:var(--mut)">z</text>':"";
  return `<svg viewBox="0 0 200 200" role="img" aria-label="Your pet, a ${SN[st]}"><ellipse cx="100" cy="170" rx="${46*s}" ry="6" fill="#000" opacity=".12"/><g transform="translate(100 170) scale(${s}) translate(-100 -170)">${glow}${ants}<ellipse cx="78" cy="162" rx="15" ry="8" fill="${B}" stroke="${L}" stroke-width="3"/><ellipse cx="122" cy="162" rx="15" ry="8" fill="${B}" stroke="${L}" stroke-width="3"/><ellipse cx="100" cy="120" rx="48" ry="42" fill="${B}" stroke="${L}" stroke-width="3"/>${patt(sk,"bc")}${belly}${plates}${badge}<circle cx="70" cy="124" r="5" fill="#FF8FA3" opacity=".55"/><circle cx="130" cy="124" r="5" fill="#FF8FA3" opacity=".55"/>${eye(84)}${eye(116)}${specs}<path d="${mouth}" fill="none" stroke="${I}" stroke-width="3" stroke-linecap="round"/>${flames}${halo}${orbit}${zz}</g></svg>`;
}

function patt(sk,id){
  const p=sk.p;if(!p)return '';let g='';
  if(p==='stripes')for(let i=0;i<7;i++)g+=`<path d='M${44+i*16} 70l-28 100' stroke='#fff' stroke-opacity='.3' stroke-width='7'/>`;
  if(p==='waves')for(let i=0;i<4;i++)g+=`<path d='M44 ${96+i*16}q14-9 28 0t28 0 28 0 28 0' fill='none' stroke='#fff' stroke-opacity='.4' stroke-width='3'/>`;
  if(p==='spots')g=`<g fill='#fff' fill-opacity='.28'><circle cx='68' cy='98' r='6'/><circle cx='122' cy='92' r='5'/><circle cx='136' cy='130' r='7'/><circle cx='66' cy='140' r='5'/><circle cx='112' cy='152' r='4'/></g>`;
  if(p==='code')g=`<g font-family='ui-monospace,Menlo,monospace' font-size='12' font-weight='700' fill='#39FF88' fill-opacity='.8'><text x='80' y='99'>&lt;/&gt;</text><text x='52' y='150'>{ }</text><text x='124' y='152'>01</text></g>`;
  if(p==='stars')g=`<g fill='#fff'><circle cx='66' cy='96' r='2'/><circle cx='82' cy='84' r='1.5'/><circle cx='124' cy='90' r='2.2'/><circle cx='140' cy='116' r='1.6'/><circle cx='60' cy='130' r='1.8'/><circle cx='138' cy='148' r='2'/><circle cx='76' cy='152' r='1.5'/><path d='M112 140l2 5 5 2-5 2-2 5-2-5-5-2 5-2z'/></g>`;
  if(p==='shine')g=`<path d='M62 100q8-22 36-26' fill='none' stroke='#fff' stroke-opacity='.75' stroke-width='6' stroke-linecap='round'/><circle cx='116' cy='84' r='3' fill='#fff' fill-opacity='.8'/><circle cx='132' cy='102' r='2' fill='#fff' fill-opacity='.7'/>`;
  return `<clipPath id='${id}'><ellipse cx='100' cy='120' rx='48' ry='42'/></clipPath><g clip-path='url(#${id})'>${g}</g>`;
}

function mini(sk,col){
  const B=sk.c||col,L=sk.l||'#1B1B2F',I=sk.i||'#1B1B2F';
  return `<svg viewBox='40 66 120 112' aria-hidden='true'><ellipse cx='100' cy='120' rx='48' ry='42' fill='${B}' stroke='${L}' stroke-width='3'/>${patt(sk,'m'+sk.id)}<circle cx='84' cy='112' r='8' fill='#fff'/><circle cx='116' cy='112' r='8' fill='#fff'/><circle cx='85' cy='113' r='4.2' fill='#1B1B2F'/><circle cx='117' cy='113' r='4.2' fill='#1B1B2F'/><path d='M90 129q10 11 20 0' fill='none' stroke='${I}' stroke-width='3' stroke-linecap='round'/></svg>`;
}
