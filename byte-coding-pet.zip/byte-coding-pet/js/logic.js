// Pure logic: constants, XP/streak/coin maths. No DOM access, so it can be unit-tested in Node.
const TH=[0,25,100,250,500],SN=["Egg","Hatchling","Critter","Coder","Legend"],TIERS=[20,60,120],FP={25:6,50:12,90:20};
const TR=[["sp","🔥","Spark","showing up and keeping streaks","#FF8A3D"],["fo","🎯","Focus","deep focus time","#4C7DFF"],["cr","🛠️","Craft","tests, small commits, tidy-ups","#25B592"],["cu","📚","Curiosity","learning new things","#A56BFF"]];
const MOOD={happy:"fed and happy",nap:"napping on your rest day",ready:"ready for today’s snack",sleepy:"dozing, no rush",miss:"missing you, come back anytime"};
const pad=n=>String(n).padStart(2,"0");
const key=d=>d.getFullYear()+"-"+pad(d.getMonth()+1)+"-"+pad(d.getDate());
const today=()=>key(new Date());
const dayDiff=(a,b)=>Math.round((new Date(b)-new Date(a))/864e5);
const tier=p=>TIERS.filter(t=>p>=t).length;
const stageOf=x=>TH.filter(t=>x>=t).length-1;
const SKINS=[
{id:'classic',n:'Classic',price:0},
{id:'sunset',n:'Sunset',price:30,c:'#FF9E6D',p:'stripes'},
{id:'ocean',n:'Ocean',price:30,c:'#3FA7D6',p:'waves'},
{id:'moss',n:'Moss',price:45,c:'#6BB36F',p:'spots'},
{id:'terminal',n:'Terminal',price:60,c:'#10261A',l:'#39FF88',i:'#39FF88',p:'code'},
{id:'cosmic',n:'Cosmic',price:80,c:'#3A2B7A',i:'#FFFFFF',p:'stars'},
{id:'gold',n:'Golden',price:120,c:'#F0BE3A',p:'shine'}];
const skinOf=id=>SKINS.find(k=>k.id===id)||SKINS[0];
function calc(days){
  const ks=Object.keys(days).sort(),P={sp:0,fo:0,cr:0,cu:0},xpd={};
  let run=0,best=0,prev=null,earn=0;
  for(const k of ks){
    const d=days[k];
    run=prev&&dayDiff(prev,k)===1?run+1:1;
    best=Math.max(best,run);
    const a=(d.r?6:10)+Math.min(run-1,7),b=FP[d.f]||0,c=(d.t?8:0)+(d.s?8:0)+(d.y?6:0),e=d.l?12:0;
    P.sp+=a;P.fo+=b;P.cr+=c;P.cu+=e;xpd[k]=a+b+c+e;earn+=Math.floor(xpd[k]/2)+(run%7===0?15:0);prev=k;
  }
  const last=ks[ks.length-1],gap=last?dayDiff(last,today()):99;
  return {P,xp:P.sp+P.fo+P.cr+P.cu,streak:last&&gap<=1?run:0,best,gap,xpd,earn};
}

if(typeof module!=="undefined"&&module.exports){
  module.exports={TH,SN,TIERS,FP,TR,SKINS,pad,key,today,dayDiff,tier,stageOf,skinOf,calc};
}
