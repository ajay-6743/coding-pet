// App state, UI rendering, persistence and event handlers.
const $=s=>document.querySelector(s);
let S={name:"Byte",days:{},own:['classic'],skin:'classic'},store=null,draft=null;
const spent=()=>S.own.reduce((a,id)=>a+skinOf(id).price,0);
const blank=()=>Object.assign({f:0,t:0,s:0,y:0,l:0},S.days[today()]||{});

function buy(id){
  const sk=skinOf(id),fresh=!S.own.includes(id);
  if(fresh){if(Math.max(0,calc(S.days).earn-spent())<sk.price)return;S.own.push(id);}
  S.skin=id;save();render();
  $('#smsg').textContent=fresh?`Bought ${sk.n} for ${sk.price} coins. ${S.name} is wearing it now.`:`${S.name} is now wearing ${sk.n}.`;
}

function render(){
  const c=calc(S.days),st=stageOf(c.xp),T={};
  TR.forEach(t=>T[t[0]]=tier(c.P[t[0]]));
  const dom=TR.slice().sort((a,b)=>c.P[b[0]]-c.P[a[0]])[0],col=c.xp?dom[4]:"#B9A8FF";
  const td=S.days[today()],mood=td?(td.r?"nap":"happy"):c.gap<=1?"ready":c.gap<=3?"sleepy":"miss";
  const nxt=TH[st+1],prog=nxt?(c.xp-TH[st])/(nxt-TH[st]):1;
  const sk=skinOf(S.skin),bal=Math.max(0,c.earn-spent());
  $("#stage").innerHTML=pet(st,T,sk.c||col,mood,prog,sk);
  $("#stage").style.setProperty("--tint",col+"55");
  if($("#nm")!==document.activeElement)$("#nm").value=S.name;
  $("#fn").textContent=S.name;
  $("#coin").textContent="🪙 "+bal;
  $("#skins").innerHTML=SKINS.map(k=>{
    const own=S.own.includes(k.id),on=S.skin===k.id,lock=!own&&bal<k.price;
    return `<div class="sk${on?" on":""}">${mini(k,col)}<b>${k.n}</b><button type="button" class="btn" data-k="${k.id}"${on?' aria-pressed="true"':""}${on||lock?" disabled":""}${lock?` title="Need ${k.price-bal} more coins"`:""}>${on?"Equipped":own?"Equip":"🪙 "+k.price}</button></div>`;
  }).join("");
  $("#sub").textContent=st===0?(c.xp?"Egg, warming up":"Egg, waiting for its first check-in"):SN[st]+", "+MOOD[mood];
  $("#xpb").style.width=Math.round(prog*100)+"%";
  $("#xpt").textContent=nxt?`${c.xp} XP, ${nxt-c.xp} more to become a ${SN[st+1]}`:`${c.xp} XP, fully grown`;
  $("#traits").innerHTML=TR.map(t=>{
    const p=c.P[t[0]],ti=T[t[0]],lo=TIERS[ti-1]||0,hi=TIERS[ti],pc=hi?Math.round((p-lo)/(hi-lo)*100):100;
    return `<div class="tr"><span class="ic">${t[1]}</span><div><b>${t[2]}</b> <span class="mut">${t[3]}</span><div class="bar"><i style="width:${pc}%;background:${t[4]}"></i></div></div><span class="lv">Lv ${ti}<small>${p} pts</small></span></div>`;
  }).join("");
  const ds=[];
  for(let i=13;i>=0;i--){const d=new Date();d.setDate(d.getDate()-i);ds.push(key(d));}
  $("#hist").innerHTML=ds.map(k=>{
    const e=S.days[k],x=c.xpd[k]||0,lv=!e?0:e.r?1:x>=40?4:x>=25?3:2;
    return `<i class="h h${lv}" title="${k}: ${e?x+" XP":"no check-in"}"></i>`;
  }).join("");
  $("#streak").textContent=(c.streak?`${c.streak}-day streak`:"No streak right now")+(c.best?`, best ${c.best}. Rest days keep it alive.`:". Rest days keep it alive.");
}

function syncForm(){
  document.querySelectorAll("[data-f]").forEach(b=>b.setAttribute("aria-pressed",String(+b.dataset.f===draft.f)));
  document.querySelectorAll("[data-c]").forEach(b=>b.setAttribute("aria-pressed",String(!!draft[b.dataset.c])));
}

function save(){
  try{localStorage.setItem("bytepet",JSON.stringify(S));}catch(e){}
  try{if(store)store.set(S).catch(()=>{});}catch(e){}
}

function log(rest){
  const before=calc(S.days),sb=stageOf(before.xp),k=today(),g=(S.days[k]||{}).g||0;
  S.days[k]=rest?{f:0,t:0,s:0,y:0,l:0,r:1,g}:Object.assign({},draft,{r:0,g});
  const after=calc(S.days),sa=stageOf(after.xp),gain=after.xp-before.xp,cg=after.earn-before.earn;
  save();render();
  const h=$("#stage");h.classList.remove("pop");void h.offsetWidth;h.classList.add("pop");
  $("#msg").textContent=sa>sb?`${S.name} grew into a ${SN[sa]}! +${gain} XP, +${cg} coins`:gain>0?`+${gain} XP, +${cg} coins. ${rest?"Rest counts, your streak is safe.":"Nice work."}`:"Today’s check-in updated.";
}

function doImport(){
  const by={};
  $("#gl").value.split("\n").forEach(r=>{
    const i=r.indexOf("|"),k=i<0?"":r.slice(0,i).trim();
    if(/^\d{4}-\d{2}-\d{2}$/.test(k))(by[k]=by[k]||[]).push(r.slice(i+1));
  });
  const ks=Object.keys(by);let n=0;
  ks.forEach(k=>{
    const m=by[k].join(" "),d=S.days[k]||{f:0,t:0,s:0,y:0,l:0};
    n+=by[k].length;d.g=by[k].length;
    d.t=d.t||/test|spec/i.test(m)?1:0;
    d.s=d.s||by[k].length>=3?1:0;
    d.y=d.y||/refactor|clean|tidy|rename/i.test(m)?1:0;
    d.l=d.l||/learn|try|trying|experiment|spike|prototype|explor/i.test(m)?1:0;
    S.days[k]=d;
  });
  if(ks.length){save();draft=blank();syncForm();render();}
  $("#impmsg").textContent=ks.length?`Imported ${n} commits across ${ks.length} days.`:"No lines matched. Use the command above, which prints date|message.";
}

function demo(){
  let a=0,i=1;
  while(a<7&&i<400){
    const d=new Date();d.setDate(d.getDate()-i);const k=key(d);
    if(!S.days[k]){const r=()=>Math.random()<.5?1:0;S.days[k]={f:[0,25,50,90][Math.floor(Math.random()*4)],t:r(),s:r(),y:r(),l:r(),r:0,g:0};a++;}
    i++;
  }
  save();render();
}

function wipe(b){
  if(b.dataset.arm){S.days={};S.own=['classic'];S.skin='classic';delete b.dataset.arm;b.textContent="Start over";save();draft=blank();syncForm();render();$("#msg").textContent="";return;}
  b.dataset.arm=1;b.textContent="Click again to erase everything";
  setTimeout(()=>{delete b.dataset.arm;b.textContent="Start over";},4000);
}

document.addEventListener("click",e=>{
  const b=e.target.closest("button");if(!b)return;
  if(b.dataset.f!==undefined){draft.f=+b.dataset.f;syncForm();}
  else if(b.dataset.c){draft[b.dataset.c]=draft[b.dataset.c]?0:1;syncForm();}
  else if(b.dataset.k)buy(b.dataset.k);
  else if(b.id==="feed")log(false);
  else if(b.id==="rest")log(true);
  else if(b.id==="imp")doImport();
  else if(b.id==="demo")demo();
  else if(b.id==="wipe")wipe(b);
});
$("#nm").addEventListener("change",e=>{S.name=e.target.value.trim()||"Byte";save();render();});

async function init(){
  let loaded=false;
  try{
    if(typeof claude!=="undefined"){
      const u=await claude.use("user"),db=await claude.use("db"),id=u&&await u.id();
      if(db&&id){
        store=db.doc("data/users/"+id+"/pet");
        const snap=await store.get();
        if(snap.exists){S=Object.assign({name:"Byte",days:{}},snap.data());loaded=true;}
      }
    }
  }catch(e){}
  if(!loaded){
    try{const r=localStorage.getItem("bytepet");if(r)S=Object.assign({name:"Byte",days:{}},JSON.parse(r));}catch(e){}
  }
  S.days=S.days||{};S.own=S.own||['classic'];S.skin=S.skin||'classic';draft=blank();syncForm();render();
}

draft=blank();syncForm();render();
init();
